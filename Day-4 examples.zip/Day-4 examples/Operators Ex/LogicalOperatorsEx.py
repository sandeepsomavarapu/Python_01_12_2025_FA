a = True
b = False
print(a and b)
print(a or b)
print(not a)
# logical AND
print(True and True)     # True
print(True and False)    # False

# logical OR
print(True or False)     # True

# logical NOT
print(not True)          # False