a=10   
b=20   
print("a > b is ",a>b)   
print("a >= b is ",a>=b)   
print("a < b is ",a<b)   
print("a <= b is ",a<=b)   
