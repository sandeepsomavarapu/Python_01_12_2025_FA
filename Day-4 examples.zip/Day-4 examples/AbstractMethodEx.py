
from abc import ABC, abstractmethod


class Test(ABC):
    @abstractmethod
    def m1(self):
        pass
    @abstractmethod
    def m2(self):
        pass

obj=Test()
