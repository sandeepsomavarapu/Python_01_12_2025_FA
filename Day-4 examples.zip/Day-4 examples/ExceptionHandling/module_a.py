def display():
    print("am from display function of module_a")