from module_a import display,display1
display()
display1()