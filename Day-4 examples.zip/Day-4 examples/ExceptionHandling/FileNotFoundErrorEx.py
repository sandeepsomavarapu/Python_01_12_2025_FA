# f=open("kpmg.txt","r")
# print(f.read())
# f.close()
with open('hello.py',"r") as f:
    data=f.read()