

import re
 
def validate_mobile_number(mobile_number):
    pattern = re.compile('^\d{10}$')
    return bool(pattern.match(mobile_number))
 
# Testing the function
mobile_numbers = ['9876543210', '1234567890', '1234', '12345678901', '123456789a']
for mobile_number in mobile_numbers:
    if validate_mobile_number(mobile_number):
        print(f"{mobile_number} is a valid mobile number")
    else:
        print(f"{mobile_number} is an invalid mobile number")