from openpyxl import Workbook
wb = Workbook()
ws = wb.active
print(ws)
print(ws.active_cell)
ws1 = wb.create_sheet("mydata") # insert at the end (default)
ws2 = wb.create_sheet("Mysheet1", 0) # insert at first position
ws.title = "New Title Active"
ws3 = wb["New Title Active"]
print(wb.sheetnames)
wb.save('balances.xlsx')
print(tuple(ws.rows))
print(tuple(ws.columns))
print(wb.sheetnames)
sheet = wb["mydata"] 
print(sheet)
print(wb.get_sheet_by_name("mydata"))