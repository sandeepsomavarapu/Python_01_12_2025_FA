from openpyxl import load_workbook  
wb = load_workbook('demo.xlsx')  
  
sheet = wb.active  
sheet['A1'] = 'Suresh Kumar'  
  
sheet.cell(row=2, column=2).value = 5  
wb.save('demo.xlsx')  