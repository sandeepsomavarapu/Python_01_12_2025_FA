from math import *
print(sqrt(21))